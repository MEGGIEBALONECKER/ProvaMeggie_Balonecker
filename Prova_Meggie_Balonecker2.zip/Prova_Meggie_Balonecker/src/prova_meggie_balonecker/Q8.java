/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_meggie_balonecker;

import java.io.IOException;
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.PrintWriter;
/**
 *
 * @author mbalonecker
 */
public class Q8 {
    public static void main(String[] args) throws IOException {
      String nome,peso,categoria;
      float Peso;
      
      nome = JOptionPane.showInputDialog("Digite o nome do Lutador: ");
      peso = JOptionPane.showInputDialog("Digite o Peso do Lutador; ");
      Peso = Float.parseFloat(peso);
      
      if(Peso < 65){
       categoria = "Pena";   
      }
      else
          if((Peso >=65) & (Peso< 72)){
              categoria = "Leve";
          }
      else
              if((Peso>=72)&(Peso<79)){
                  categoria = "Ligeiro";
              }
      else
                  if((Peso>=79)&(Peso<86)){
                      categoria = "Meio Medio";
                  }
      else
                      if((Peso>=86)&(Peso<93)){
                          categoria = "Medio";
                      }
      else
                          if((Peso>=93)&(Peso<100)){
                              categoria = "Meio Pesado";
                          }
                          else{
                              categoria = "Pesado";
                          }
      
        
       FileWriter arquivo = new FileWriter("C:\\Users\\mbalonecker\\Desktop\\Prova_Meggie_Balonecker\\LUTADOR.txt"); 
       PrintWriter gravarq = new PrintWriter(arquivo);
       
       gravarq.print("Nome Fornecido: "+nome);
       gravarq.print("\nPeso Fornecido: "+peso);
       gravarq.print("\nCategoria: "+categoria);
       gravarq.print("\n----------------------\n");
       gravarq.print("O Lutador "+nome+" pesa "+peso+"KG e se enquadra na categoria "+categoria);
       
       arquivo.close();
       
       JOptionPane.showMessageDialog(null, "Salvo com Sucesso!");
       
        
    }
}
