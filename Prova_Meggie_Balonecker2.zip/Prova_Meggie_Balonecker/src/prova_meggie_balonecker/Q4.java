/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_meggie_balonecker;

import java.io.IOException;
import java.io.DataInputStream;

/**
 *
 * @author mbalonecker
 */
public class Q4 {
    public static void main(String[] args) throws IOException {
      DataInputStream dado = new DataInputStream(System.in);
      String cod,sen;
      int codigo,senha;
      
      System.out.println("Digite o Codigo de Usuario: ");
      cod = dado.readLine();
      codigo = Integer.parseInt(cod);
      
      if(codigo != 1234){
          System.out.println("Usuario Invalido!");
      }
      else {
          System.out.println("Digite a senha: ");
          sen = dado.readLine();
          senha = Integer.parseInt(sen);
          
          if(senha != 9999){
              System.out.println("Acesso Negado");
          }
          else{
              System.out.println("Acesso Permitido");
          }
      }
      
        
        
        
        
        
        
    }
}
