/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prova_meggie_balonecker;
import java.io.DataInputStream;
import java.io.IOException;
/**
 *
 * @author mbalonecker
 */
public class Q1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
       DataInputStream dado = new DataInputStream(System.in);
       String anos,meses,dias;
       int Anos,Meses,Dias,total;
       
       System.out.println("Digite quantos anos você tem: ");
       anos = dado.readLine();
       System.out.println("Digite quantos meses de idade voce tem?");
       meses = dado.readLine();
       System.out.println("Digite quantos dias de idade vc tem: ");
       dias = dado.readLine();
       
      Anos = Integer.parseInt(anos);
      Meses = Integer.parseInt(meses);
      Dias = Integer.parseInt(dias);
      
      
     total = (Anos*365)+(Meses*30)+ Dias;
             
        System.out.println(Anos+" Anos, "+Meses+" Meses, "+Dias+" Dias = "+total+"Dias");
       
        
        
    }
    
}
