/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_meggie_balonecker;

import java.io.IOException;
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.PrintWriter;
/**
 *
 * @author mbalonecker
 */
public class Q7 {
     public static void main(String[] args) throws IOException {
         
         try{
         
         String numero;
         float num ;
         
       
         numero = JOptionPane.showInputDialog("Digite um Numero: ");
         num = Float.parseFloat(numero);
         
         
        FileWriter arquivo = new FileWriter("C:\\Users\\mbalonecker\\Desktop\\Prova_Meggie_Balonecker\\TABUADA.txt");
        PrintWriter gravarq =  new PrintWriter(arquivo);
         
        
        gravarq.print("TABUADA "+num+".\n\n");
        int a =1;
        while(a<=10){
            gravarq.print("|"+a+" * "+num+" = "+(a*num)+"| \n");
            a++;
        }
        
        arquivo.close();
     
         JOptionPane.showMessageDialog(null, "Arquivo salvo com Sucesso em: C:\\Users\\mbalonecker\\Desktop\\Prova_Meggie_Balonecker\\TABUADA.txt");
         
         }
         catch(NumberFormatException e){
             System.out.println("Ocorreu um erro: "+e.getMessage());
         }
     }

}
