/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_meggie_balonecker;

import java.io.IOException;
import javax.swing.JOptionPane;
import java.io.DataInputStream;

/**
 *
 * @author mbalonecker
 */
public class Q3 {
    
    public static void main(String[] args) throws IOException {
       
        try{
        
        String numero;
        int num;
        
      
       numero = JOptionPane.showInputDialog("Digite um numero: ");
       num = Integer.parseInt(numero);
       
       JOptionPane.showMessageDialog(null, "O antecessorde "+num+" é "+(num-1));
       JOptionPane.showMessageDialog(null,"O sucessor de "+num+" é: "+(num+1));
        
        
        
        }
        catch(NumberFormatException e){
            System.out.println("Ocorreu um erro; "+e.getMessage());
        }
    }
    
}
