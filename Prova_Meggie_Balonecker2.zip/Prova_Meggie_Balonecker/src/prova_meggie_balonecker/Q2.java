/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_meggie_balonecker;
import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author mbalonecker
 */
public class Q2 {
    
  
    
    
    
    public static void main(String[] args) throws IOException {
        
     
     try{   
   
    
      DataInputStream dado = new DataInputStream(System.in);
      String opcao;
      int opc,qtdCafeExp=0,qtdCafeCap=0,qtdLeite=0,qtdTotal=0;
      double totalVendido=0, totalCafeExp=0,totalCafeCap=0,totalLeite=0;
      boolean encerrar = true;
      
      while(encerrar){
     
      
      
      System.out.println(" Digite a opcao desejada: \n");
      System.out.println("1- Cafe Expresso RS 0.75\n2- Cafe Capuccino RS1.00\n3- Leite com Cafe RS 1.25\n4- Totalizar Vendas");
      opcao = dado.readLine();
       opc = Integer.parseInt(opcao);
      while(opc<1 || opc>4 ){
          System.out.println("Opcao Digitada Invalida\nDigite novamente: \n");
          System.out.println("1- Cafe Expresso RS 0.75\n2- Cafe Capuccino RS1.00\n3- Leite com Cafe RS 1.25\n4- Totalizar Vendas");
          System.out.println("");
          opcao = dado.readLine();
           opc = Integer.parseInt(opcao);
      }
     opc = Integer.parseInt(opcao);
      if(opc == 1){
          qtdTotal++;
          totalVendido = totalVendido + 0.75;
          qtdCafeExp++;
          totalCafeExp = totalCafeExp + 0.75;
          
      
      }
      else
          if(opc ==2){
          qtdTotal++;
          totalVendido = totalVendido + 1.00;
          qtdCafeCap++;
          totalCafeCap = totalCafeCap + 1.00;
          }
      else
              if(opc == 3){
                  qtdTotal++;
                  totalVendido = totalVendido + 1.25;
                  qtdLeite++;
                  totalLeite = totalLeite + 1.25;
              }
      else
                  if(opc == 4){
                      System.out.println("TOTAL DE VENDAS: ");
                      System.out.println(" Quantidade Cafe Expresso - "+qtdCafeExp*(0.75));
                      System.out.println("Quantidade Cafe Capuccino - "+qtdCafeCap*(1.00));
                      System.out.println("Quantidade Leite com Cafe - "+qtdLeite*(1.25));
                      System.out.println("Total Cafe Expresso R$ "+totalCafeExp);
                      System.out.println("Total Cafe Capuccino R$ "+totalCafeCap);
                      System.out.println("Total Leite com Cafe R$ "+totalLeite);
                      System.out.println("Quantidade de Cafes Vendidos: "+(qtdCafeExp+qtdCafeCap+qtdLeite));
                      System.out.println("Total de Cafes Vendidos R$"+totalVendido);
                      encerrar = false;
                      
                  }
      }
     }
      catch(NumberFormatException e){
          System.out.println("Ocorreu um Erro: "+e.getMessage());
      }
      
      
      
    
    }
      
      
      
    }
    
    
    

      
      
        
        
        
        
    
    

