/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_meggie_balonecker;

import java.io.IOException;
import java.io.DataInputStream;
/**
 *
 * @author mbalonecker
 */
public class Q5 {
    
     public static void main(String[] args) throws IOException {
         
         try{
         DataInputStream dado = new DataInputStream(System.in);
         String numero,Qtd;
         float num,soma =0,media =0;
         int repet;
         
         
       System.out.println("Digite a quantidade de numeros que sera calculada: ");
       Qtd = dado.readLine();
       repet = Integer.parseInt(Qtd);
       
       
       for(int i =0;i<repet;i++){
           System.out.println("Digite um numero: ");
           numero = dado.readLine();
           num = Float.parseFloat(numero);
           soma = soma + num;
     
       }
       
       media = soma/repet;
       
       System.out.println("Quantidade de Valores Digitados: "+repet);
       System.out.println("Soma dos Valores Digitados: "+soma);
       System.out.println("Media dos Valores Digitados: "+media);
         }
         catch(NumberFormatException e){
             System.out.println("Ocorreu um Erro: "+e.getMessage());
         }
         catch (NullPointerException e1){
             System.out.println("Ocorreu um erro: "+e1.getMessage());
         }
         
         
     }
    
}
